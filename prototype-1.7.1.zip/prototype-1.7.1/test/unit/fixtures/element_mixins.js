Form.Element.Methods.coffee = Prototype.K;
Element.addMethods();